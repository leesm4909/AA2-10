# mkdirp-classic

Just a non-deprecated mirror of [mkdirp 0.5.2](https://github.com/substack/node-mkdirp/tree/0.5.1)
for use in modules where we depend on the non promise interface.

```
npm install mkdirp-classic
```

## Usage

``` js
// See the above link
```

## License

MIT
