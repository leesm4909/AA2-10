
0.1.1 / 2016-02-16
==================

  * add logger.verbose

0.1.0 / 2014-04-04
==================

 * add ci
 * add critical, alert and emergency
 * docs

0.0.1 - February 27, 2013
-------------------------
:sparkles:
